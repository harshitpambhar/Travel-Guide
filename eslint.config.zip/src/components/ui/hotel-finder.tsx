import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { COUNTRIES } from "@/components/ui/countries";

// Example: Static state mapping (replace with API if needed)
const STATES: Record<string, string[]> = {
  US: ["California", "Texas", "New York"],
  IN: ["Maharashtra", "Delhi", "Karnataka"],
  FR: ["Île-de-France", "Provence-Alpes-Côte d'Azur"],
  // ...
};

// Example: Mock hotel data
const HOTELS: Record<string, { name: string; address: string; rating: number }[]> = {
  "US-California": [
    { name: "Hotel California", address: "Los Angeles", rating: 4.5 },
    { name: "Bay Area Inn", address: "San Francisco", rating: 4.2 },
  ],
  "IN-Delhi": [
    { name: "Delhi Grand", address: "Connaught Place", rating: 4.3 },
  ],
  // ...
};

export function HotelFinder() {
  const [country, setCountry] = useState<string>("");
  const [state, setState] = useState<string>("");
  const [search, setSearch] = useState<string>("");
  const [filteredCountries, setFilteredCountries] = useState(COUNTRIES);

  useEffect(() => {
    setFilteredCountries(
      COUNTRIES.filter(c =>
        c.name.toLowerCase().includes(search.toLowerCase())
      )
    );
  }, [search]);

  const states = country ? STATES[country] || [] : [];
  const hotels = country && state ? HOTELS[`${country}-${state}`] || [] : [];

  return (
    <div className="space-y-4 max-w-xl mx-auto">
      <h2 className="text-2xl font-bold mb-2">Find Hotels</h2>
      <Input
        placeholder="Search country"
        value={search}
        onChange={e => setSearch(e.target.value)}
      />
      <Select value={country} onValueChange={setCountry}>
        <SelectTrigger>
          <SelectValue placeholder="Select country" />
        </SelectTrigger>
        <SelectContent>
          {filteredCountries.map(c => (
            <SelectItem key={c.code} value={c.code}>{c.name}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      {states.length > 0 && (
        <Select value={state} onValueChange={setState}>
          <SelectTrigger>
            <SelectValue placeholder="Select state/region" />
          </SelectTrigger>
          <SelectContent>
            {states.map(s => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
      {hotels.length > 0 && (
        <div className="grid gap-3">
          {hotels.map((h, i) => (
            <Card key={i} className="p-4">
              <div className="font-medium">{h.name}</div>
              <div className="text-sm text-muted-foreground">{h.address}</div>
              <div className="text-sm">Rating: {h.rating}</div>
            </Card>
          ))}
        </div>
      )}
      {country && state && hotels.length === 0 && (
        <div className="text-muted-foreground">No hotels found for this region.</div>
      )}
    </div>
  );
}
