import { Header } from "@/components/layout/header";
import { HeroSection } from "@/components/sections/hero-section";
import { CategoriesSection } from "@/components/sections/categories-section";
import { FeaturedExperiences } from "@/components/sections/featured-experiences";
import { useState } from "react";
import { HotelFinder } from "@/components/ui/hotel-finder";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16">
        <HeroSection />
        <CategoriesSection />
        <FeaturedExperiences />
      </main>
    </div>
  );
};

export function HotelsPage() {
  return (
    <div className="max-w-2xl mx-auto py-10">
      <h1 className="text-3xl font-bold mb-4">Hotels</h1>
      <HotelFinder />
    </div>
  );
}

export default Index;
